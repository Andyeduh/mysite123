Site institucional (demo) - Conteúdo incluído
--------------------------------------------
Arquivos no pacote:
- index.html        (página inicial)
- services.html     (página de serviços)
- login.html        (área de login - demo)
- styles.css        (estilos modernos e responsivos)
- script.js         (comportamento: menu + login demo)
- README.txt        (este arquivo)

Como testar localmente:
1) Descompacte o ZIP e abra `index.html` no navegador.
2) Para testar o login use as credenciais demo: cliente@exemplo.com / senha123
   (autenticação é feita no front-end apenas para demo; não use em produção)
3) Para produção, substitua o código de `script.js` pela integração ao seu backend
   (endpoints / JWT / cookies seguros / HTTPS etc.).

Observações rápidas de segurança e próximos passos:
- Implementar backend (Node/Express, Django, Laravel, etc.) com endpoints de login,
  verificação por token (JWT) e armazenar senhas com hash bcrypt/argon2.
- Usar HTTPS, cookies seguros (HttpOnly, Secure, SameSite) ou Authorization header.
- Melhorar SEO: meta tags, Open Graph, sitemap.xml e robots.txt.
- Requisitos adicionais (integração com CRM, e-mail, área do cliente com dashboard)
  podem ser integrados conforme especificação.

Precisa que eu já gere o dashboard protegido ou integre com um backend (Node/Express)?
Se sim, diga qual backend prefere e já eu te entrego os arquivos correspondentes.
