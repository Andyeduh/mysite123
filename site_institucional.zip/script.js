
// Basic interactive behaviour + demo auth (client-side only).
// WARNING: This is a front-end demo. Do not use client-side auth for production.
document.addEventListener('DOMContentLoaded', function(){
  // set year in footer(s)
  const y = new Date().getFullYear();
  document.getElementById('year') && (document.getElementById('year').textContent = y);
  document.getElementById('year2') && (document.getElementById('year2').textContent = y);

  // burger menu for small screens
  const burger = document.getElementById('burgerBtn') || document.getElementById('burgerBtn2');
  if(burger){
    burger.addEventListener('click', ()=>{
      const nav = document.querySelector('.nav');
      if(nav) nav.style.display = (nav.style.display === 'flex') ? 'none' : 'flex';
    });
  }

  // demo login behaviour
  const loginForm = document.getElementById('loginForm');
  if(loginForm){
    loginForm.addEventListener('submit', function(e){
      e.preventDefault();
      const email = document.getElementById('email').value.trim();
      const password = document.getElementById('password').value.trim();

      // Demo credentials (replace with API call)
      const demoEmail = 'cliente@exemplo.com';
      const demoPass = 'senha123';

      if(email === demoEmail && password === demoPass){
        // create a demo token in localStorage
        localStorage.setItem('token', btoa(email + ':' + Date.now()));
        localStorage.setItem('user', email);
        alert('Login realizado com sucesso! Você será redirecionado para a página inicial.');
        window.location.href = 'index.html';
      } else {
        alert('Credenciais inválidas. Use a conta demo exibida na página, ou substitua este sistema por sua API de autenticação.');
      }
    });
  }

  // show login state
  const user = localStorage.getItem('user');
  const loginBtnHeader = document.getElementById('loginBtnHeader');
  if(user && loginBtnHeader){
    loginBtnHeader.textContent = 'Olá, ' + user.split('@')[0];
    loginBtnHeader.classList.remove('btn-outline');
    loginBtnHeader.href = 'index.html';
    // add logout on click
    loginBtnHeader.addEventListener('click', function(e){
      e.preventDefault();
      if(confirm('Deseja sair?')){
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.reload();
      }
    });
  }
});
